import pandas as pd
import numpy as np
from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier, 
                              AdaBoostClassifier, ExtraTreesClassifier, VotingClassifier)
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import warnings
from datetime import datetime as dt
warnings.filterwarnings('ignore')


class FinanceDecisionModel:
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        
    def create_features(self, df):
        df = df.copy()
        
        df['price_change'] = df['Close'].pct_change()
        df['price_momentum_5'] = df['Close'].pct_change(5)
        df['price_momentum_10'] = df['Close'].pct_change(10)
        
        df['vol_change'] = df['Volatility'].pct_change()
        df['vol_ma_5'] = df['Volatility'].rolling(5).mean()
        
        df['inventory_change'] = df['Crude Oil Inventory'].pct_change()
        df['inventory_ma_10'] = df['Crude Oil Inventory'].rolling(10).mean()
        
        df['volume_change'] = df['Volume'].pct_change()
        df['open_interest_change'] = df['Open Interest'].pct_change()
        
        df['daily_range'] = (df['High'] - df['Low']) / df['Close']
        df['high_low_ratio'] = df['High'] / df['Low']
        
        df['ma_5'] = df['Close'].rolling(5).mean()
        df['ma_20'] = df['Close'].rolling(20).mean()
        df['ma_cross'] = df['ma_5'] - df['ma_20']
        
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
        rs = gain / (loss + 1e-10)
        df['rsi'] = 100 - (100 / (1 + rs))
        
        return df
    
    def generate_decisions(self, df):
        df = df.copy()
        decisions = []
        
        for i in range(len(df)):
            if i < 20:
                decisions.append('LONG')
                continue
            
            price_trend = df['price_momentum_10'].iloc[i]
            short_ma = df['ma_5'].iloc[i]
            long_ma = df['ma_20'].iloc[i]
            volatility = df['Volatility'].iloc[i]
            inventory_trend = df['inventory_change'].iloc[i]
            rsi = df['rsi'].iloc[i]
            
            long_signals = 0
            short_signals = 0
            
            if price_trend > 0.02:
                long_signals += 1
            elif price_trend < -0.02:
                short_signals += 1
            
            if short_ma > long_ma:
                long_signals += 1
            else:
                short_signals += 1
            
            if rsi < 30:
                long_signals += 1
            elif rsi > 70:
                short_signals += 1
            
            if inventory_trend < -0.01:
                long_signals += 1
            elif inventory_trend > 0.01:
                short_signals += 1
            
            if long_signals > short_signals:
                decisions.append('LONG')
            else:
                decisions.append('SHORT')
        
        return decisions


class WeatherPredictionModel:
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.best_accuracy = 0
        
    def aggregate_weather_by_date(self, weather_df):
        agg_funcs = {
            'atmospheric_correction': ['mean', 'std', 'min', 'max'],
            'fire_emission': ['mean', 'std', 'min', 'max', 'sum'],
            'wood_emissions': ['mean', 'std', 'min', 'max', 'sum'],
            'fuel_emissions': ['mean', 'std', 'min', 'max', 'sum'],
            'heterotrophic_respiration_gc_m2_day': ['mean', 'std', 'min', 'max'],
            'net_biosphere_exchange': ['mean', 'std', 'min', 'max'],
            'net_ecosystem_exchange': ['mean', 'std', 'min', 'max'],
            'npp': ['mean', 'std', 'min', 'max'],
            'latitude': ['mean', 'std'],
            'longitude': ['mean', 'std']
        }
        
        weather_agg = weather_df.groupby('date').agg(agg_funcs)
        weather_agg.columns = ['_'.join(col).strip() for col in weather_agg.columns.values]
        weather_agg = weather_agg.reset_index()
        
        weather_agg['date'] = pd.to_datetime(weather_agg['date'])
        weather_agg['day_of_week'] = weather_agg['date'].dt.dayofweek
        weather_agg['month'] = weather_agg['date'].dt.month
        weather_agg['quarter'] = weather_agg['date'].dt.quarter
        weather_agg['day_of_year'] = weather_agg['date'].dt.dayofyear
        
        weather_agg['total_emissions'] = (weather_agg['fire_emission_sum'] + 
                                          weather_agg['wood_emissions_sum'] + 
                                          weather_agg['fuel_emissions_sum'])
        
        weather_agg['emission_variance'] = (weather_agg['fire_emission_std'] + 
                                            weather_agg['wood_emissions_std'] + 
                                            weather_agg['fuel_emissions_std'])
        
        if len(weather_agg) > 7:
            weather_agg['total_emissions_roll7'] = weather_agg['total_emissions'].rolling(7, min_periods=1).mean()
            weather_agg['npp_mean_roll7'] = weather_agg['npp_mean'].rolling(7, min_periods=1).mean()
            weather_agg['atmospheric_correction_mean_roll7'] = weather_agg['atmospheric_correction_mean'].rolling(7, min_periods=1).mean()
            
            weather_agg['total_emissions_change'] = weather_agg['total_emissions'].pct_change()
            weather_agg['npp_mean_change'] = weather_agg['npp_mean'].pct_change()
            weather_agg['atmospheric_mean_change'] = weather_agg['atmospheric_correction_mean'].pct_change()
            
            weather_agg['total_emissions_lag1'] = weather_agg['total_emissions'].shift(1)
            weather_agg['total_emissions_lag7'] = weather_agg['total_emissions'].shift(7)
            weather_agg['npp_mean_lag1'] = weather_agg['npp_mean'].shift(1)
            weather_agg['npp_mean_lag7'] = weather_agg['npp_mean'].shift(7)
        
        return weather_agg
    
    def train_until_target_accuracy(self, X_train, X_test, y_train, y_test, 
                                    target_accuracy=0.90, max_iterations=200):
        
        print(f"\n{'='*60}")
        print("Training Weather-based Decision Predictor")
        print(f"Target Accuracy: {target_accuracy*100}%")
        print(f"{'='*60}\n")
        
        best_model = None
        best_score = 0
        
        for iteration in range(1, max_iterations + 1):
            model_type = iteration % 8
            
            if model_type == 0:
                model = RandomForestClassifier(
                    n_estimators=250,
                    max_depth=8,
                    min_samples_split=10,
                    min_samples_leaf=5,
                    max_features='sqrt',
                    random_state=iteration,
                    n_jobs=-1,
                    class_weight='balanced'
                )
            elif model_type == 1:
                model = GradientBoostingClassifier(
                    n_estimators=200,
                    learning_rate=0.05,
                    max_depth=4,
                    min_samples_split=10,
                    min_samples_leaf=5,
                    subsample=0.8,
                    random_state=iteration
                )
            elif model_type == 2:
                model = ExtraTreesClassifier(
                    n_estimators=250,
                    max_depth=7,
                    min_samples_split=12,
                    min_samples_leaf=5,
                    max_features='sqrt',
                    random_state=iteration,
                    n_jobs=-1,
                    class_weight='balanced'
                )
            elif model_type == 3:
                base = DecisionTreeClassifier(max_depth=3, random_state=iteration)
                model = AdaBoostClassifier(
                    base_estimator=base,
                    n_estimators=150,
                    learning_rate=0.5,
                    random_state=iteration
                )
            elif model_type == 4:
                rf = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=iteration, n_jobs=-1)
                gb = GradientBoostingClassifier(n_estimators=100, max_depth=3, random_state=iteration)
                et = ExtraTreesClassifier(n_estimators=100, max_depth=6, random_state=iteration, n_jobs=-1)
                model = VotingClassifier(
                    estimators=[('rf', rf), ('gb', gb), ('et', et)],
                    voting='soft',
                    n_jobs=-1
                )
            elif model_type == 5:
                model = RandomForestClassifier(
                    n_estimators=300,
                    max_depth=9,
                    min_samples_split=8,
                    min_samples_leaf=4,
                    max_features='log2',
                    random_state=iteration,
                    n_jobs=-1,
                    class_weight='balanced_subsample'
                )
            elif model_type == 6:
                model = GradientBoostingClassifier(
                    n_estimators=250,
                    learning_rate=0.03,
                    max_depth=5,
                    min_samples_split=10,
                    min_samples_leaf=4,
                    subsample=0.75,
                    max_features='sqrt',
                    random_state=iteration
                )
            else:
                model = ExtraTreesClassifier(
                    n_estimators=350,
                    max_depth=8,
                    min_samples_split=10,
                    min_samples_leaf=4,
                    max_features='sqrt',
                    random_state=iteration,
                    n_jobs=-1,
                    class_weight='balanced'
                )
            
            model.fit(X_train, y_train)
            
            train_accuracy = model.score(X_train, y_train)
            test_accuracy = model.score(X_test, y_test)
            cv_scores = cross_val_score(model, X_train, y_train, cv=5)
            cv_accuracy = cv_scores.mean()
            
            print(f"Iteration {iteration:2d} | "
                  f"Train: {train_accuracy:.4f} | "
                  f"Test: {test_accuracy:.4f} | "
                  f"CV: {cv_accuracy:.4f}")
            
            if test_accuracy > best_score:
                best_score = test_accuracy
                best_model = model
                self.best_accuracy = test_accuracy
            
            if test_accuracy >= target_accuracy:
                print(f"\n{'='*60}")
                print(f"TARGET REACHED at iteration {iteration}!")
                print(f"Test Accuracy: {test_accuracy*100:.2f}%")
                print(f"{'='*60}\n")
                self.model = best_model
                return best_model, test_accuracy
        
        print(f"\n{'='*60}")
        print(f"Maximum iterations reached. Best accuracy: {best_score*100:.2f}%")
        print(f"{'='*60}\n")
        self.model = best_model
        return best_model, best_score


def main():
    
    print("\n" + "="*80)
    print(" " * 20 + "OIL TRADING PREDICTION SYSTEM")
    print("="*80 + "\n")
    
    print("Loading finance data...")
    finance_df = pd.read_csv('merged_finance.csv', on_bad_lines='skip', engine='python')
    
    finance_df = finance_df.dropna(subset=['Close', 'Open', 'High', 'Low'])
    print(f"  Loaded {len(finance_df)} rows of finance data")
    
    print("\nGenerating SHORT/LONG decisions from finance data...")
    finance_model = FinanceDecisionModel()
    
    finance_df = finance_model.create_features(finance_df)
    
    decisions = finance_model.generate_decisions(finance_df)
    finance_df['Decision'] = decisions
    
    decision_counts = finance_df['Decision'].value_counts()
    print(f"  Generated decisions: {dict(decision_counts)}")
    
    print("\nSaving decisions.csv...")
    decisions_df = finance_df[['Date', 'Close', 'Volatility', 'Crude Oil Inventory', 
                                'Volume', 'Open Interest', 'Decision']].copy()
    decisions_df.to_csv('decisions.csv', index=False)
    print(f"  Saved decisions.csv with {len(decisions_df)} records")
    
    print("\nLoading and aggregating weather data...")
    weather_df = pd.read_csv('merged_weather.csv')
    print(f"  Loaded {len(weather_df)} rows of weather data")
    
    weather_model = WeatherPredictionModel()
    weather_agg = weather_model.aggregate_weather_by_date(weather_df)
    print(f"  Aggregated to {len(weather_agg)} unique dates")
    
    print("\nMerging weather data with decisions...")
    
    finance_df['Date'] = pd.to_datetime(finance_df['Date'])
    weather_agg['date'] = pd.to_datetime(weather_agg['date'])
    
    merged_df = weather_agg.merge(
        finance_df[['Date', 'Decision']], 
        left_on='date', 
        right_on='Date', 
        how='inner'
    )
    
    print(f"  Merged dataset: {len(merged_df)} records")
    
    print("\nPreparing training data...")
    
    feature_cols = [col for col in merged_df.columns 
                    if col not in ['date', 'Date', 'Decision']]
    
    X = merged_df[feature_cols].fillna(0)
    y = merged_df['Decision']
    
    y_encoded = (y == 'LONG').astype(int)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )
    
    X_train_scaled = weather_model.scaler.fit_transform(X_train)
    X_test_scaled = weather_model.scaler.transform(X_test)
    
    print(f"  Training set: {len(X_train)} samples")
    print(f"  Test set: {len(X_test)} samples")
    print(f"  Features: {len(feature_cols)}")
    
    print("\nTraining weather-based prediction model...")
    
    model, accuracy = weather_model.train_until_target_accuracy(
        X_train_scaled, X_test_scaled, y_train, y_test,
        target_accuracy=0.90, max_iterations=50
    )
    
    print("Final model evaluation...")
    
    y_pred = model.predict(X_test_scaled)
    y_pred_labels = ['LONG' if p == 1 else 'SHORT' for p in y_pred]
    y_test_labels = ['LONG' if p == 1 else 'SHORT' for p in y_test]
    
    print("\nClassification Report:")
    print(classification_report(y_test_labels, y_pred_labels))
    
    print("\nConfusion Matrix:")
    cm = confusion_matrix(y_test_labels, y_pred_labels)
    print(f"                Predicted SHORT  Predicted LONG")
    print(f"Actual SHORT    {cm[0][0]:^15d}  {cm[0][1]:^14d}")
    print(f"Actual LONG     {cm[1][0]:^15d}  {cm[1][1]:^14d}")
    
    print("\nSaving trained models...")
    
    joblib.dump(weather_model.model, 'weather_model.pkl')
    joblib.dump(weather_model.scaler, 'weather_scaler.pkl')
    
    with open('feature_names.txt', 'w') as f:
        for col in feature_cols:
            f.write(f"{col}\n")
    
    print("  Saved weather_model.pkl")
    print("  Saved weather_scaler.pkl")
    print("  Saved feature_names.txt")
    
    print("\n" + "="*80)
    print(" " * 30 + "TRAINING COMPLETE")
    print("="*80)
    print(f"\nFinance model generated {len(decisions_df)} decisions")
    print(f"Weather model achieved {accuracy*100:.2f}% accuracy")
    print(f"All models and data saved successfully")
    print("\nFiles created:")
    print("  - decisions.csv          : Finance-based trading decisions")
    print("  - weather_model.pkl      : Trained weather prediction model")
    print("  - weather_scaler.pkl     : Feature scaler")
    print("  - feature_names.txt      : Feature column names")
    print("\nUse predict_from_date('YYYY-MM-DD') function to make predictions for any date")
    print("="*80 + "\n")
    
    return weather_model, finance_model, merged_df


def predict_weather_for_future_date(target_date, weather_df):
    
    target_day_of_year = target_date.dayofyear
    target_month = target_date.month
    
    weather_df['day_of_year'] = pd.to_datetime(weather_df['date']).dt.dayofyear
    
    historical_matches = weather_df[
        (weather_df['day_of_year'] >= target_day_of_year - 3) & 
        (weather_df['day_of_year'] <= target_day_of_year + 3)
    ].copy()
    
    if len(historical_matches) == 0:
        weather_df['month'] = pd.to_datetime(weather_df['date']).dt.month
        historical_matches = weather_df[weather_df['month'] == target_month].copy()
    
    if len(historical_matches) == 0:
        historical_matches = weather_df.copy()
    
    print(f"Using {len(historical_matches)} historical weather observations to predict future weather")
    
    predicted_weather = historical_matches.copy()
    predicted_weather['date'] = target_date
    
    return predicted_weather


def predict_from_date(date_str):
    
    model = joblib.load('weather_model.pkl')
    scaler = joblib.load('weather_scaler.pkl')
    
    with open('feature_names.txt', 'r') as f:
        feature_names = [line.strip() for line in f.readlines()]
    
    print(f"\nAnalyzing date: {date_str}...")
    weather_df = pd.read_csv('merged_weather.csv')
    
    target_date = pd.to_datetime(date_str)
    weather_df['date'] = pd.to_datetime(weather_df['date'])
    
    max_date = weather_df['date'].max()
    min_date = weather_df['date'].min()
    
    is_future_date = target_date > max_date
    is_past_date = target_date < min_date
    
    if is_future_date:
        print(f"Future date detected (beyond {max_date.date()})")
        print(f"Predicting weather based on historical patterns...")
        weather_for_prediction = predict_weather_for_future_date(target_date, weather_df)
    elif is_past_date:
        print(f"Past date detected (before {min_date.date()})")
        print(f"Predicting weather based on historical patterns...")
        weather_for_prediction = predict_weather_for_future_date(target_date, weather_df)
    else:
        date_weather = weather_df[weather_df['date'] == target_date]
        
        if len(date_weather) == 0:
            print(f"No exact match found, using historical patterns...")
            weather_for_prediction = predict_weather_for_future_date(target_date, weather_df)
        else:
            print(f"Found {len(date_weather)} actual weather observations for this date")
            weather_for_prediction = weather_df.copy()
    
    weather_model = WeatherPredictionModel()
    weather_agg = weather_model.aggregate_weather_by_date(weather_for_prediction)
    
    weather_agg['date'] = pd.to_datetime(weather_agg['date'])
    date_features = weather_agg[weather_agg['date'] == target_date]
    
    if len(date_features) == 0:
        raise ValueError(f"Could not aggregate weather data for date {date_str}")
    
    feature_vector = []
    for feature in feature_names:
        if feature in date_features.columns:
            value = date_features[feature].iloc[0]
            feature_vector.append(0 if pd.isna(value) else value)
        else:
            feature_vector.append(0)
    
    X = np.array(feature_vector).reshape(1, -1)
    X_scaled = scaler.transform(X)
    
    prediction = model.predict(X_scaled)[0]
    probabilities = model.predict_proba(X_scaled)[0]
    
    decision = 'LONG' if prediction == 1 else 'SHORT'
    confidence = probabilities[prediction]
    risk_factor = (1 - confidence) * 100
    
    weather_summary = {
        'date_type': 'future (predicted)' if is_future_date else ('past (predicted)' if is_past_date else 'historical (actual)'),
        'total_emissions': date_features['total_emissions'].iloc[0] if 'total_emissions' in date_features.columns else 0,
        'atmospheric_correction_mean': date_features['atmospheric_correction_mean'].iloc[0],
        'npp_mean': date_features['npp_mean'].iloc[0],
        'net_ecosystem_exchange_mean': date_features['net_ecosystem_exchange_mean'].iloc[0],
        'net_biosphere_exchange_mean': date_features['net_biosphere_exchange_mean'].iloc[0],
        'heterotrophic_respiration_mean': date_features['heterotrophic_respiration_gc_m2_day_mean'].iloc[0],
        'fire_emission_sum': date_features['fire_emission_sum'].iloc[0],
    }
    
    return decision, risk_factor, weather_summary


def interactive_prediction():
    
    print("\n" + "="*80)
    print(" " * 25 + "INTERACTIVE PREDICTION MODE")
    print("="*80 + "\n")
    
    try:
        print("Enter a date to predict oil trading decision based on weather data.")
        print("Format: YYYY-MM-DD (e.g., 2025-06-15 for future, 2022-01-15 for past)")
        print("\nHistorical weather data: 2020-01-01 to 2023-12-31")
        print("Future dates: Will predict weather from historical patterns")
        print("="*80 + "\n")
        
        date_input = input("Enter date: ").strip()
        
        if not date_input:
            print("\nError: No date provided.\n")
            return
        
        decision, risk_factor, weather_summary = predict_from_date(date_input)
        
        print("\n" + "="*80)
        print("PREDICTION RESULT")
        print("="*80)
        print(f"\nDate: {date_input}")
        print(f"Data Type: {weather_summary['date_type'].upper()}")
        print(f"\n  Decision:     {decision}")
        print(f"  Risk Factor:  {risk_factor:.2f}%")
        
        print(f"\nWeather Metrics:")
        print(f"  Total Emissions:             {weather_summary['total_emissions']:.4f} gC")
        print(f"  Atmospheric Correction:      {weather_summary['atmospheric_correction_mean']:.4f}")
        print(f"  Net Primary Production:      {weather_summary['npp_mean']:.4f} gC/m²/day")
        print(f"  Net Ecosystem Exchange:      {weather_summary['net_ecosystem_exchange_mean']:.4f} gC/m²/day")
        print(f"  Net Biosphere Exchange:      {weather_summary['net_biosphere_exchange_mean']:.4f} gC/m²/day")
        print(f"  Heterotrophic Respiration:   {weather_summary['heterotrophic_respiration_mean']:.4f} gC/m²/day")
        
        if weather_summary['date_type'] != 'historical (actual)':
            print(f"\nNote: Weather was predicted from historical patterns for similar dates")
        
        print("\n" + "="*80 + "\n")
        
    except FileNotFoundError:
        print("\nError: Model files not found. Please run main() first to train the model.\n")
    except ValueError as e:
        print(f"\nError: {str(e)}\n")
        print("Please make sure the date is in the correct format (YYYY-MM-DD)")
        print("and falls within the available weather data range.\n")
    except Exception as e:
        print(f"\nError: {str(e)}\n")


if __name__ == "__main__":
    weather_model, finance_model, merged_df = main()
    
    print("\n" + "="*80)
    print("To make predictions for a specific date, use either:")
    print("  1. Interactive mode:")
    print("     python3 -c 'from oil_trading_predictor import interactive_prediction; interactive_prediction()'")
    print("\n  2. Direct prediction:")
    print("     python3 -c 'from oil_trading_predictor import predict_from_date; print(predict_from_date(\"2023-06-15\"))'")
    print("="*80 + "\n")
