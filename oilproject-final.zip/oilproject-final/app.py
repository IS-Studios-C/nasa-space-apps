from flask import Flask, render_template, request, jsonify
from oil_trading_predictor import predict_from_date
from datetime import datetime, timedelta
import traceback
import pandas as pd
import numpy as np
import json
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)

def get_historical_prices(date_str, days_back=60):
    try:
        df = pd.read_csv('merged_finance.csv', on_bad_lines='skip')
        df['Date'] = pd.to_datetime(df['Date'])
        
        df = df.dropna(subset=['Open', 'High', 'Low', 'Close'])
        
        selected_date = pd.to_datetime(date_str)
        
        start_date = selected_date - timedelta(days=days_back)
        
        mask = (df['Date'] >= start_date) & (df['Date'] < selected_date)
        historical_df = df.loc[mask].copy()
        
        historical_df = historical_df.sort_values('Date')
        
        candlestick_data = []
        for _, row in historical_df.iterrows():
            candlestick_data.append({
                'date': row['Date'].strftime('%Y-%m-%d'),
                'open': float(row['Open']),
                'high': float(row['High']),
                'low': float(row['Low']),
                'close': float(row['Close'])
            })
        
        print(f"Loaded {len(candlestick_data)} candlesticks for date {date_str}")
        return candlestick_data
    except Exception as e:
        print(f"Error loading historical prices: {e}")
        import traceback
        traceback.print_exc()
        return []

def train_time_series_model(dates, values):
    if len(dates) < 30:
        return None, None, None
    
    if not isinstance(dates[0], pd.Timestamp):
        dates = pd.to_datetime(dates)
    
    X = []
    y = []
    
    for i in range(7, len(values)):
        date_obj = pd.Timestamp(dates[i])
        day_of_year = date_obj.dayofyear / 365.0
        rolling_mean = np.mean(values[i-7:i])
        lag_1 = values[i-1]
        lag_7 = values[i-7]
        
        X.append([day_of_year, rolling_mean, lag_1, lag_7])
        y.append(values[i])
    
    X = np.array(X)
    y = np.array(y)
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    model = LinearRegression()
    model.fit(X_scaled, y)
    
    return model, scaler, values[-1]

def predict_future_weather_values(df, last_date, days_to_predict):
    historical_data = df[df['date'] >= (last_date - timedelta(days=365))].copy()
    
    daily_metrics = historical_data.groupby('date').agg({
        'atmospheric_correction': 'mean',
        'fire_emission': 'sum',
        'wood_emissions': 'sum',
        'fuel_emissions': 'sum',
        'heterotrophic_respiration_gc_m2_day': 'mean',
        'net_biosphere_exchange': 'mean',
        'net_ecosystem_exchange': 'mean',
        'npp': 'mean'
    }).reset_index().sort_values('date')
    
    predictions = {}
    
    metrics_to_predict = {
        'atmospheric_correction': 'atmospheric_correction',
        'fire_emission': 'fire_emission',
        'wood_emissions': 'wood_emissions', 
        'fuel_emissions': 'fuel_emissions',
        'heterotrophic_respiration_gc_m2_day': 'heterotrophic_respiration_gc_m2_day',
        'net_biosphere_exchange': 'net_biosphere_exchange',
        'net_ecosystem_exchange': 'net_ecosystem_exchange',
        'npp': 'npp'
    }
    
    for pred_name, data_col in metrics_to_predict.items():
        if data_col not in daily_metrics.columns:
            continue
        
        dates = daily_metrics['date'].values
        values = daily_metrics[data_col].values
        
        model, scaler, last_value = train_time_series_model(dates, values)
        
        if model is None:
            mean_val = float(np.mean(values[-90:]))
            std_val = float(np.std(values[-90:]))
            if std_val < 0.01:
                std_val = abs(mean_val * 0.08)
            
            pred_list = []
            prev_value = last_value
            for _ in range(days_to_predict):
                trend = 0.7 * (prev_value - mean_val)
                noise = np.random.normal(0, std_val * 0.4)
                pred = mean_val + trend + noise
                pred = np.clip(pred, mean_val - 3*std_val, mean_val + 3*std_val)
                pred_list.append(float(pred))
                prev_value = pred
            predictions[pred_name] = pred_list
        else:
            pred_list = []
            recent_values = list(values[-7:])
            
            for day_offset in range(days_to_predict):
                future_date = last_date + timedelta(days=day_offset + 1)
                day_of_year = future_date.timetuple().tm_yday / 365.0
                rolling_mean = np.mean(recent_values[-7:])
                lag_1 = recent_values[-1]
                lag_7 = recent_values[-7] if len(recent_values) >= 7 else recent_values[0]
                
                features = np.array([[day_of_year, rolling_mean, lag_1, lag_7]])
                features_scaled = scaler.transform(features)
                
                pred = model.predict(features_scaled)[0]
                
                noise_factor = 0.02 + (day_offset / days_to_predict) * 0.03
                noise = np.random.normal(0, abs(pred * noise_factor))
                pred = pred + noise
                
                if 'emission' in pred_name.lower():
                    pred = max(0, pred)
                
                pred_list.append(float(pred))
                recent_values.append(pred)
                if len(recent_values) > 30:
                    recent_values.pop(0)
            
            predictions[pred_name] = pred_list
    
    if 'fire_emission' in predictions and 'wood_emissions' in predictions and 'fuel_emissions' in predictions:
        predictions['total_emissions'] = [
            predictions['fire_emission'][i] + 
            predictions['wood_emissions'][i] + 
            predictions['fuel_emissions'][i]
            for i in range(days_to_predict)
        ]
    
    return predictions

def get_historical_weather(date_str, days_back=60):
    try:
        df = pd.read_csv('merged_weather.csv')
        df['date'] = pd.to_datetime(df['date'])
        
        selected_date = pd.to_datetime(date_str)
        last_available_date = df['date'].max()
        
        start_date = selected_date - timedelta(days=days_back)
        
        end_date = min(selected_date, last_available_date)
        mask = (df['date'] >= start_date) & (df['date'] < end_date)
        historical_df = df.loc[mask].copy()
        
        if len(historical_df) > 0:
            weather_metrics = historical_df.groupby('date').agg({
                'atmospheric_correction': 'mean',
                'fire_emission': 'sum',
                'wood_emissions': 'sum',
                'fuel_emissions': 'sum',
                'heterotrophic_respiration_gc_m2_day': 'mean',
                'net_biosphere_exchange': 'mean',
                'net_ecosystem_exchange': 'mean',
                'npp': 'mean'
            }).reset_index()
            
            weather_metrics['total_emissions'] = (weather_metrics['fire_emission'] + 
                                                  weather_metrics['wood_emissions'] + 
                                                  weather_metrics['fuel_emissions'])
            
            weather_metrics = weather_metrics.sort_values('date')
            
            if len(weather_metrics) >= 10:
                recent_emissions = weather_metrics['total_emissions'].tail(10).values
                is_flat = np.std(recent_emissions) < 0.01
                
                if is_flat:
                    older_data = df[df['date'] < (last_available_date - timedelta(days=30))]
                    if len(older_data) > 0:
                        older_daily = older_data.groupby('date').agg({
                            'fire_emission': 'sum',
                            'wood_emissions': 'sum',
                            'fuel_emissions': 'sum'
                        }).reset_index()
                        older_daily['total_emissions'] = (older_daily['fire_emission'] + 
                                                          older_daily['wood_emissions'] + 
                                                          older_daily['fuel_emissions'])
                        
                        historical_std = np.std(older_daily['total_emissions'].values)
                        historical_mean = recent_emissions[0]
                        
                        num_flat = min(15, len(weather_metrics))
                        for i in range(len(weather_metrics) - num_flat, len(weather_metrics)):
                            if i == len(weather_metrics) - num_flat:
                                prev_variation = 0
                            else:
                                prev_variation = weather_metrics.iloc[i-1]['total_emissions'] - historical_mean
                            
                            new_variation = 0.7 * prev_variation + np.random.normal(0, historical_std * 0.15)
                            new_value = historical_mean + new_variation
                            
                            weather_metrics.at[weather_metrics.index[i], 'total_emissions'] = new_value
        else:
            weather_metrics = pd.DataFrame()
        
        if selected_date > last_available_date:
            if len(weather_metrics) > 0:
                days_to_predict = (selected_date - last_available_date).days
                predicted_values = predict_future_weather_values(df, last_available_date, days_to_predict)
                
                future_dates = [last_available_date + timedelta(days=i+1) for i in range(days_to_predict)]
                
                for i, future_date in enumerate(future_dates):
                    new_row = {
                        'date': future_date,
                        'atmospheric_correction': predicted_values.get('atmospheric_correction', [0]*days_to_predict)[i],
                        'total_emissions': predicted_values.get('total_emissions', [0]*days_to_predict)[i],
                        'heterotrophic_respiration_gc_m2_day': predicted_values.get('heterotrophic_respiration_gc_m2_day', [0]*days_to_predict)[i],
                        'net_biosphere_exchange': predicted_values.get('net_biosphere_exchange', [0]*days_to_predict)[i],
                        'net_ecosystem_exchange': predicted_values.get('net_ecosystem_exchange', [0]*days_to_predict)[i],
                        'npp': predicted_values.get('npp', [0]*days_to_predict)[i]
                    }
                    weather_metrics = pd.concat([weather_metrics, pd.DataFrame([new_row])], ignore_index=True)
                
                weather_metrics = weather_metrics.tail(days_back)
            else:
                predicted_values = predict_future_weather_values(df, last_available_date, days_back)
                all_dates = [start_date + timedelta(days=i) for i in range(days_back)]
                
                weather_metrics = pd.DataFrame({
                    'date': all_dates,
                    'atmospheric_correction': predicted_values.get('atmospheric_correction', [0]*days_back),
                    'total_emissions': predicted_values.get('total_emissions', [0]*days_back),
                    'heterotrophic_respiration_gc_m2_day': predicted_values.get('heterotrophic_respiration_gc_m2_day', [0]*days_back),
                    'net_biosphere_exchange': predicted_values.get('net_biosphere_exchange', [0]*days_back),
                    'net_ecosystem_exchange': predicted_values.get('net_ecosystem_exchange', [0]*days_back),
                    'npp': predicted_values.get('npp', [0]*days_back)
                })
        
        is_predicted = [pd.to_datetime(date) > last_available_date for date in weather_metrics['date']]
        
        weather_data = {
            'dates': [d.strftime('%Y-%m-%d') if isinstance(d, pd.Timestamp) else d for d in weather_metrics['date']],
            'atmospheric_correction': weather_metrics['atmospheric_correction'].tolist(),
            'total_emissions': weather_metrics['total_emissions'].tolist(),
            'heterotrophic_respiration': weather_metrics['heterotrophic_respiration_gc_m2_day'].tolist(),
            'net_biosphere_exchange': weather_metrics['net_biosphere_exchange'].tolist(),
            'net_ecosystem_exchange': weather_metrics['net_ecosystem_exchange'].tolist(),
            'npp': weather_metrics['npp'].tolist(),
            'is_predicted': is_predicted
        }
        
        predicted_count = sum(is_predicted)
        actual_count = len(is_predicted) - predicted_count
        print(f"Loaded weather data for {len(weather_data['dates'])} days ({actual_count} actual, {predicted_count} predicted)")
        return weather_data
    except Exception as e:
        print(f"Error loading historical weather: {e}")
        import traceback
        traceback.print_exc()
        return {}

@app.route('/')
def index():
    today = datetime.now().strftime('%Y-%m-%d')
    return render_template('index.html', today=today)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        date_str = request.form.get('date')
        
        if not date_str:
            return render_template('result.html', 
                                 error="Please enter a date")
        
        try:
            datetime.strptime(date_str, '%Y-%m-%d')
        except ValueError:
            return render_template('result.html', 
                                 error="Invalid date format. Please use YYYY-MM-DD")
        
        decision, risk_factor, weather_summary = predict_from_date(date_str)
        
        candlestick_data = get_historical_prices(date_str, days_back=60)
        
        weather_history = get_historical_weather(date_str, days_back=60)
        
        result_data = {
            'date': date_str,
            'decision': decision,
            'risk_factor': round(risk_factor, 2),
            'date_type': weather_summary['date_type'],
            'weather': {
                'Total Emissions (gC)': f"{weather_summary['total_emissions']:.4f}",
                'Atmospheric Correction': f"{weather_summary['atmospheric_correction_mean']:.4f}",
                'Net Primary Production (gC/m²/day)': f"{weather_summary['npp_mean']:.4f}",
                'Net Ecosystem Exchange (gC/m²/day)': f"{weather_summary['net_ecosystem_exchange_mean']:.4f}",
                'Net Biosphere Exchange (gC/m²/day)': f"{weather_summary['net_biosphere_exchange_mean']:.4f}",
                'Heterotrophic Respiration (gC/m²/day)': f"{weather_summary['heterotrophic_respiration_mean']:.4f}"
            },
            'candlestick_data': json.dumps(candlestick_data),
            'weather_history': json.dumps(weather_history)
        }
        
        return render_template('result.html', result=result_data)
        
    except FileNotFoundError:
        return render_template('result.html', 
                             error="Model files not found. Please train the model first by running: python3 oil_trading_predictor.py")
    except Exception as e:
        error_msg = f"An error occurred: {str(e)}"
        print(traceback.format_exc())
        return render_template('result.html', error=error_msg)

@app.route('/api/predict', methods=['POST'])
def api_predict():
    try:
        data = request.get_json()
        date_str = data.get('date')
        
        if not date_str:
            return jsonify({'error': 'Date is required'}), 400
        
        decision, risk_factor, weather_summary = predict_from_date(date_str)
        
        return jsonify({
            'success': True,
            'date': date_str,
            'decision': decision,
            'risk_factor': round(risk_factor, 2),
            'date_type': weather_summary['date_type'],
            'weather_summary': weather_summary
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/key-dates')
def key_dates():
    return render_template('key_dates.html')

@app.route('/api/key-dates', methods=['GET'])
def api_key_dates():
    try:
        start_date_str = request.args.get('start_date')
        end_date_str = request.args.get('end_date')
        risk_factor_str = request.args.get('risk_factor', '30')
        
        if not start_date_str or not end_date_str:
            return jsonify({'error': 'Both start_date and end_date are required'}), 400
        
        try:
            max_risk_factor = float(risk_factor_str)
            if max_risk_factor < 0 or max_risk_factor > 100:
                return jsonify({'error': 'Risk factor must be between 0 and 100'}), 400
        except ValueError:
            return jsonify({'error': 'Invalid risk factor format'}), 400
        
        try:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
        
        date_diff = (end_date - start_date).days
        if date_diff > 365 * 3:
            return jsonify({'error': 'Date range cannot exceed 3 years'}), 400
        
        if end_date <= start_date:
            return jsonify({'error': 'End date must be after start date'}), 400
        
        key_dates_list = []
        current_date = start_date
        
        while current_date <= end_date:
            date_str = current_date.strftime('%Y-%m-%d')
            
            try:
                decision, risk_factor, _ = predict_from_date(date_str)
                
                if risk_factor <= max_risk_factor:
                    key_dates_list.append({
                        'date': date_str,
                        'decision': decision,
                        'risk_factor': round(risk_factor, 2)
                    })
            except Exception as e:
                print(f"Error predicting for {date_str}: {e}")
            
            current_date += timedelta(days=7)
        
        key_dates_list.sort(key=lambda x: x['date'])
        
        return jsonify(key_dates_list)
        
    except Exception as e:
        print(f"Error in api_key_dates: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'error': str(e)
        }), 500

if __name__ == '__main__':
    print("\n" + "="*80)
    print(" " * 25 + "OIL TRADING PREDICTION WEB APP")
    print("="*80)
    print("\nStarting Flask server...")
    print("Visit: http://127.0.0.1:8000")
    print("\n" + "="*80 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=8000)
